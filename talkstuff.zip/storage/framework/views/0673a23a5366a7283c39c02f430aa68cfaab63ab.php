<router-link tag="li" :to="{name : 'users'}" class="bg-hover-darkGray">
    <a href="#" class="fg-white">
        <i class="uk-margin-small-right fa fa-user fa-2x uk-text-middle"></i>
        Users
    </a>
</router-link>

<?php $__env->startSection('scripts'); ?>
    <script src="/themes/controlPanel/views/users/users.js"></script>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<?php $__env->stopSection(); ?>