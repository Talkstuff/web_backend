<?php $__env->startSection('app'); ?>
    <login></login>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="/build/app.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="/themes/controlPanel/views/security/login.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('controlPanel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>