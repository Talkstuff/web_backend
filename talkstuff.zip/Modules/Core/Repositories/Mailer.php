<?php
/**
 * Created by PhpStorm.
 * User: Dennis
 * Date: 15/06/2017
 * Time: 02:52 PM
 */

namespace Modules\Core\Repositories;


class Mailer
{
    public function sendMail()
    {

    }

}