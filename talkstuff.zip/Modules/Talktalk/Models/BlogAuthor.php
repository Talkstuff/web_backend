<?php

namespace Modules\Talktalk\Models;

use Illuminate\Database\Eloquent\Model;

class BlogAuthor extends \LeeOvery\WordpressToLaravel\Author
{
    protected $table = 'blog_authors';
}
